//ex02.js
alert('반갑습니다.');